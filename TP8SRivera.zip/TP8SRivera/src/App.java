import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;  
public class App {
    

    public static void main(String[] args) {

        Pieza pieza = new Pieza(null, 0, 0, 0, 
        0, null, null, null);
        
        Scanner miScan = new Scanner(System.in);    
        
        ArrayList<Pieza> piezas = new ArrayList<>(); 


        System.out.println("Bienvenida al puente de 2 mundos DB - POO");
        
        System.out.println("Elija una opcion : ");
        
        System.out.println("1 - listar piezas desde la base de datos");
        
        System.out.println("2 - Cargar piezas a la base de datos");
        
    
        boolean flag = true;
        while (flag) {
            int op = miScan.nextInt();
            switch (op) {
                case 1:
                    MostrarDatosDeLaBaseDeDato();
                    flag = true;
                    break;  
    
                case 2:
                    InstanciarPieza(pieza,piezas);
                    CargarAlaBaseDeDatos(pieza, miScan);
                    flag = true; 
                    break;
    
                default:
                    System.out.println("Opción incorrecta");
                    flag = true;
                    break;
            }
        }
        miScan.close(); 
    }
    
   public static void InstanciarPieza(Pieza pieza, ArrayList<Pieza> piezas) {
        
        String[] posicionesPeonesBlancos = {"A2", "B2", "C2", "D2", "E2", "F2", "G2", "H2"};
        String[] posicionesPeonesNegros = {"A7", "B7", "C7", "D7", "E7", "F7", "G7", "H7"};
        String[] posicionesAlfilesBlancos = {"C1","F1"};
        String[] posicionesAlfilesNegros = {"C8","F8"};
        String[] posicionesTorresBlancas = {"A1","H1"};
        String[] posicionesTorresNegros = {"A8","H8"};
        String[] posicionesCaballosBlancos = {"B1","G1"};
        String[] posicionesCaballosNegros = {"B8","G8"};
        String[] posicionReina = {"D1", "D8"};
        String[] posicionRey = {"E1", "E8"};

        for (int i = 0; i < 8; i++) {
            Peon miPeonBlanco = new Peon(null, 0, 1, 2,
            1, posicionesPeonesBlancos[i], "1", null);
            
            Peon miPeonNegro = new Peon(null, 0, 6, 2,
             1, posicionesPeonesNegros[i], "1", null);
            
             piezas.add(miPeonBlanco); 
            
             piezas.add(miPeonNegro); 
        }

        for (int i = 0; i < 2; i++) {
            Alfil miAlfilBlanco = new Alfil(null, 0, 4,
             
            1, 1, posicionesAlfilesBlancos[i], "1", null);
           
            Alfil miAlfilNegro = new Alfil(null, 0, 4,
            
            1, 1, posicionesAlfilesNegros[i], "1", null);
            
            Torre miTorreBlanca = new Torre(null, 0, 3,
            
            1, 1, posicionesTorresBlancas[i], "1", null);
            
            Torre miTorreNegra = new Torre(null, 0, 3,
            
            1, 1, posicionesTorresNegros[i], "1", null);
            
            Caballo miCaballoBlanco = new Caballo(null, 0, 5, 
           
            1, 1, posicionesCaballosBlancos[i], "3", null);
            
            Caballo miCaballoNegro = new Caballo(null, 0, 5, 
           
            1, 1, posicionesCaballosNegros[i], "4", null);

            piezas.add(miAlfilBlanco);
            
            piezas.add(miAlfilNegro);
            
            piezas.add(miTorreBlanca);
            
            piezas.add(miTorreNegra);
            
            piezas.add(miCaballoBlanco);
            
            piezas.add(miCaballoNegro);
        }

        for (int i = 0; i < 1; i++) {
            Reina miReinaBlanca = new Reina(null, 0, 1,
             1, 1, posicionReina[0], "1", null);
            
             Reina miReinaNegra = new Reina(null, 0, 1,
              1, 1, posicionReina[1], "1", null);
            
              Rey miReyBlanco = new Rey(null, 1, 2, 
              1, 1, posicionRey[0], "1", null);
            
              Rey miReyNegro = new Rey(null, 0, 2,
               1, 1, posicionRey[1], "1", null);

            piezas.add(miReinaBlanca);
            
            piezas.add(miReinaNegra);

            piezas.add(miReyBlanco);
            
            piezas.add(miReyNegro);
        }
    }

    public static void MostrarDatosDeLaBaseDeDato()
	{
		
    	AccesoDatos accesoBD = null;
    	Connection con = null;
    	Statement sentencia = null;
		ResultSet rs = null;
		
		
		String query = "SELECT Descripcion, idColor , caracter FROM pieza";
        try {
        	accesoBD = new AccesoDatos();
			
            con = accesoBD.getConexion();
            sentencia = con.createStatement();
            
            rs  = sentencia.executeQuery(query);
            
            while(rs.next())
            {
                System.out.println( "  Pieza :   "+ rs.getString("Descripcion") +
                    " Color : "+"    "+ rs.getString("idColor")+"    "+  "Caracter :"
                     + rs.getString("caracter") );
            }
        }   
             catch (SQLException e) {
            System.err.println("Error al CARGAR DATOS");
             e.printStackTrace();
        }
       finally
        {
        	try
        	{
        		// Cierra el ResultSet
        		if (rs!= null) rs.close();
        		// Cierra la sentencia
        		if (sentencia!= null) sentencia.close();
        		// Cierra la conexion
        		if (con != null) con.close();
        		
        	}catch (SQLException e)
        	{
        		System.err.println("Error al cerrar conexion");
        	}
        }
	}

    public static void CargarAlaBaseDeDatos(Pieza pieza, Scanner miScan) {
        AccesoDatos accesoBD = new AccesoDatos();
        Connection con = null;
        PreparedStatement st = null;
    


        
        System.out.println("Seleccione el color: 1 para Blanco, 2 para Negro");
        int color = miScan.nextInt();
        int idColor = (color == 1) ? 1 : 2;
        pieza.setIdColor(idColor);


        System.out.println("Seleccione el tipo de pieza para cargar:");
        System.out.println("1. Reina | 2. Rey | 3. Torre | 4. Alfil | 5. Caballo | 6. Peon"); 
        
        int op = miScan.nextInt();
    
        switch (op) {
            case 1:
            pieza.setDescripcion("Reina");
            pieza.setIdTipoPieza(1);
                break;
            case 2:
            pieza.setDescripcion("Rey");
            pieza.setIdTipoPieza(2);
                break;
            case 3:
            pieza.setDescripcion("Torre");
            pieza.setIdTipoPieza(3);
                break;
            case 4:
            pieza.setDescripcion("Alfil");
            pieza.setIdTipoPieza(4);
                break;
            case 5:
            pieza.setDescripcion("Caballo");
            pieza.setIdTipoPieza(5);
                break;
            case 6:
            pieza.setDescripcion("Peon");
            pieza.setIdTipoPieza(6);
            break;
                default:
                System.out.println("Opción incorrecta.");
               return;
        }
        
        
        System.out.println("Seleccione el tamaño de la pieza: 1 para Pequeño, 2 para Grande");
        int tamanio = miScan.nextInt();
        pieza.setIdTamanio(tamanio); 

        
        System.out.println("Seleccione el material de la pieza 1 para Plastico , 2 para Madera");
        int material = miScan.nextInt();
        pieza.setIdMaterial(material);

        try {
            con = accesoBD.getConexion();
    
            // Consulta SQL
            String query = "INSERT INTO pieza (Descripcion, idColor, IdTipoPieza, idTamanio, idMaterial, Posicion, Caracter, Movimiento, Fecha_Creacion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            st = con.prepareStatement(query);
           
            // Asigno valores a la consulta
            st.setString(1, pieza.getDescripcion());
            st.setInt(2, pieza.getIdColor());
            st.setInt(3, pieza.getIdTipoPieza());
            st.setInt(4, pieza.getIdTamanio());
            st.setInt(5, pieza.getIdMaterial());
            st.setString(6, pieza.getPosicion());
            st.setString(7, pieza.getCaracter());
            st.setString(8, pieza.getMovimiento());
            st.setDate(9, pieza.getFecha_creacion());
            
            st.executeUpdate();
            System.out.println("Datos insertados correctamente en la base de datos.");
    
        } catch (SQLException e) {
            System.err.println("Error al insertar los datos en la base de datos.");
            e.printStackTrace();
        } finally {
            try {
                if (st != null) st.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión.");
            }
        }
        miScan.close();

    }
    
    

}

