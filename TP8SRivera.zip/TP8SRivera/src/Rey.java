import java.sql.Date;

public class Rey extends Pieza {
    public Rey(String Descripcion ,int idColor , int idTipoPieza, int  idTamanio,int idMaterial, String Posicion, String Movimiento, Date Fecha_Creacion) 
    {
    super( Descripcion, idColor ,  idTipoPieza,   idTamanio, idMaterial,  Posicion,  Movimiento,  Fecha_Creacion);
     }
    }

