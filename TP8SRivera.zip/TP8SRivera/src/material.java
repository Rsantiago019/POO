public class material {
    private int idMaterial;
    private String Descripcion;

    public material(int idMaterial, String Descripcion)
    {
        this.idMaterial = idMaterial;
        this.Descripcion = Descripcion;
    }

    public int getidMaterial() {
        return idMaterial;
    }
    public void setIdMaterial(int idMaterial) {
        this.idMaterial = idMaterial;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.Descripcion = descripcion;
    }

    
}

