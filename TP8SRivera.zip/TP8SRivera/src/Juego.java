public class Juego {
    private String Tiempo_Juego;

    public String getTiempo() {
        return Tiempo_Juego;
    }

    public void setTiempo(String tiempo) {
        Tiempo_Juego = tiempo;
    }

    public String getTiempo_Juego() {
        return Tiempo_Juego;
    }

    public void setTiempo_Juego(String tiempo_Juego) {
        Tiempo_Juego = tiempo_Juego;
    }

        // Constructor Vacio
        public Juego() {
    }

    //Constructor
    public Juego(String tiempo_Juego) {
        Tiempo_Juego = tiempo_Juego;
    }

    

    
}
