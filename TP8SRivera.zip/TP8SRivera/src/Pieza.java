import java.sql.Date;

public class  Pieza {

    // Lo que esta comentado tiene que ser
    private String Descripcion;  
    private int idColor;//  relizar una traduccion 1. negro 2. blanco
    private int  idTipoPieza;//  relizar una traduccion 1. rey, 2. reina ... 6. peon
    private int idTamanio;//  va con  null a la base de datos 
    private int idMaterial;//   va con  null a la base de datos 
    private String Posicion;
    private String Caracter;
    private String Movimiento;
    private java.sql.Date Fecha_creacion;// ponerlo con el formato para ingresarlo 



    public Pieza ( String Descripcion , int idColor , int idTipoPieza, int  idTamanio,int idMaterial, String Posicion, String Movimiento, Date Fecha_creacion) 
    {
        this.Descripcion = Descripcion;
        this.idColor = idColor;
        this.idTipoPieza= idTipoPieza;
        this.idTamanio = idMaterial;
        this.Posicion = Posicion;
        this.Movimiento = Movimiento;
        this.Fecha_creacion = Fecha_creacion;
    }


    
    public int getIdColor() {
        return idColor;
    }
    public void setIdColor(int idColor) {
        this.idColor = idColor;
    }
    public int getIdTipoPieza() {
        return idTipoPieza;
    }
    public void setIdTipoPieza(int idTipoPieza) {
        this.idTipoPieza = idTipoPieza;
    }
    public int getIdTamanio() {
        return idTamanio;
    }
    public void setIdTamanio(int idTamanio) {
        this.idTamanio = idTamanio;
    }
    public int getIdMaterial() {
        return idMaterial;
    }
    public void setIdMaterial(int idMaterial) {
        this.idMaterial = idMaterial;
    }
    public String getPosicion() {
        return Posicion;
    }
    public void setPosicion(String posicion) {
        Posicion = posicion;
    }
    public String getCaracter() {
        return Caracter;
    }
    public void setCaracter(String caracter) {
        Caracter = caracter;
    }
    public String getMovimiento() {
        return Movimiento;
    }
    public void setMovimiento(String movimiento) {
        Movimiento = movimiento;
    }
  


    public java.sql.Date getFecha_creacion() {
        return Fecha_creacion;
    }


    public void setFecha_creacion(java.sql.Date fecha_creacion) {
        Fecha_creacion = fecha_creacion;
    }



    public String getDescripcion() {
        return Descripcion;
    }



    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }


    
}
  
    
    