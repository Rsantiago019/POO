public class TransporteCargas extends Vehiculo {
    private int pesoMaximoAutorizado = 800;

    public TransporteCargas (int pesoMaximoAutorizado, String patente)
    {
        super(patente);
        this.pesoMaximoAutorizado= pesoMaximoAutorizado;
        
    }

    public int getPesoMaximoAutorizado() {
        return pesoMaximoAutorizado;
    }

    public void setPesoMaximoAutorizado(int pesoMaximoAutorizado) {
        this.pesoMaximoAutorizado = pesoMaximoAutorizado;
    }

    
}
