public class Vehiculo {
    private String patente;
    private int componente_base = 2000; // Este valor es para todas las clases
    public Vehiculo(){}

    
   

    public Vehiculo(String patente)
    {
        this.patente= patente;

    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public int getComponente_base() {
        return componente_base;
    }

    public void setComponente_base(int componente_base) {
        this.componente_base = componente_base;
    }
    public double cotizarAlquiler (int cant_dias)
    {
        return componente_base * cant_dias;

    }
}
