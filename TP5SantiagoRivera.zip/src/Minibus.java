public class Minibus extends TransportePersonas {

    public Minibus (int cant_plazas, String patente)
    {
        super (cant_plazas,patente);
    }


    @Override

    public double cotizarAlquiler(int cant_dias)
    {
        double costoBase = super.cotizarAlquiler(cant_dias);
        return costoBase + (120 * cant_plazas);
    }
}
