import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        int opcion = 0;
        Scanner scanner = new Scanner(System.in);
        Vehiculo vehiculo = null;

        System.out.println("=== Sistema de Contabilización ===");

        while (opcion != 5) {
            System.out.println("    -Bienvenido Sr Usuario-     ");
            System.out.println("---Sistema de Contabilización---");
            System.out.println("|   Elija una de las opciones   |");
            System.out.println("| 1. Cargar Auto           11. Cotizar Auto     |");
            System.out.println("| 2. Cargar Camion         22. Cotizar Camion   |");
            System.out.println("| 3. Cargar Furgoneta      33. Cotizar Furgoneta|");
            System.out.println("| 4. Cargar Minibus        44. Cotizar Minibus  |");
            System.out.println("|             0. Cerrar el Programa    ");

            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    vehiculo = instanciadorTPersonas("Auto", scanner);
                    break;
                case 2:
                    vehiculo = instanciadorTCargas("Camion", scanner);
                    break;
                case 3:
                    vehiculo = instanciadorTCargas("Furgoneta", scanner);
                    break;
                case 4:
                    vehiculo = instanciadorTPersonas("Minibus", scanner);
                    break;
                case 5:
                    System.out.println("Programa finalizado.");
                    break;
                case 11: case 22: case 33: case 44:
                    if (vehiculo != null) {
                        int dias = obtenerDiasAlquiler(scanner);
                        double cotizacion = cotizarVehiculo(vehiculo, dias);
                        System.out.println("La cotización del vehichulo,  patente: "+vehiculo.getPatente()+" es: $" + cotizacion);
                    } else {
                        System.out.println("Señor usuario. Antes de cometer esta accion, tiene que cargar el vehiculo!");
                    }
                    break;
                default:
                    System.out.println("Opción incorrecta. Intente de nuevo.");
                    break;
            }
        }

        scanner.close();
    }

    public static TransportePersonas instanciadorTPersonas(String tipo, Scanner scanner) {
        System.out.print("Ingrese la patente del " + tipo + ": ");
        String patente = scanner.next();
        System.out.print("Ingrese la cantidad de plazas: ");
        int cantPlazas = scanner.nextInt();
        System.out.println("Sea amable de elegir el tipo de vehiculo  que esté cargando 1. Auto  2. Minibus");
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                return new Auto(cantPlazas, patente);
            case 2:
                return new Minibus(cantPlazas, patente);
            default:
                System.out.println("Opcion incorrecta.");
                return null;
        }
    }

    public static TransporteCargas instanciadorTCargas(String tipo, Scanner scanner) {
        System.out.print("Ingrese la patente del " + tipo + ": ");
        String patente = scanner.next();
        System.out.print("Ingrese el peso máximo autorizado en toneladas: ");
        int pma = scanner.nextInt();
        System.out.println(" Sea amable de elegir el tipo de vehiculo que esté cargando  1. Camion  2. Furgoneta");
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                return new Camion(pma, patente);
            case 2:
                return new Furgoneta(pma, patente);
            default:
                System.out.println("Opcion incorrecta.");
                return null;
        }
    }

    public static int obtenerDiasAlquiler(Scanner scanner) {
        System.out.print("Ingrese la cantidad de dias de alquiler: ");
        return scanner.nextInt();
    }

    public static double cotizarVehiculo(Vehiculo vehiculo, int cantDias) {
        return vehiculo.cotizarAlquiler(cantDias);
    }
}
