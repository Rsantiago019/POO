public class Furgoneta extends TransporteCargas {
    

    public Furgoneta ( int pesoMaximoAutorizado, String patente)
    {
        super (pesoMaximoAutorizado,patente);
    }

    @Override

    public double cotizarAlquiler(int cant_dias)
    {
        double costoBase = super.getComponente_base() * cant_dias;
        double costoAdicional = 800 * getPesoMaximoAutorizado(); 
        return costoBase + costoAdicional;    
    }
}
