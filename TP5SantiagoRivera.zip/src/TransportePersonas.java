public class TransportePersonas extends Vehiculo {
    protected int cant_plazas;

    public TransportePersonas(int cant_plazas, String patente)
    {
        super (patente);
        this.cant_plazas= cant_plazas;
    }

    public int getCant_plazas() {
        return cant_plazas;
    }

    public void setCant_plazas(int cant_plazas) {
        this.cant_plazas = cant_plazas;
    }


}
