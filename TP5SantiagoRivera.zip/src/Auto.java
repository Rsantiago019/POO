public class Auto extends TransportePersonas {
    

    public Auto(int cant_plazas, String patente) {
        super(cant_plazas, patente);
    }


    @Override
    public double cotizarAlquiler(int cant_dias)
    {
        double costoBase = super.cotizarAlquiler(cant_dias);
        return costoBase + (100 * cant_plazas * cant_dias);
    }

}
