import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class PiezaDAO implements iPiezaDAO {

    @Override
    public void MostrarDatosDeLaBaseDeDato() {
        AccesoDatos accesoBD = null;
        Connection con = null;
        Statement sentencia = null;
        ResultSet rs = null;

        String query = "SELECT Descripcion, idColor, caracter FROM pieza";
        try {
            accesoBD = new AccesoDatos();
            con = accesoBD.getConexion();
            sentencia = con.createStatement();
            rs = sentencia.executeQuery(query);

            while (rs.next()) {
                System.out.println("Pieza: " + rs.getString("Descripcion") + " Color: " + rs.getString("idColor") + " Caracter: " + rs.getString("caracter"));
            }
        } catch (SQLException e) {
            System.err.println("Error al CARGAR DATOS");
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (sentencia != null) sentencia.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar conexion");
            }
        }
    }

    @Override
    public void InsertarAlaBaseDeDatos(Pieza pieza) {
        AccesoDatos accesoBD = new AccesoDatos();
        Connection con = null;
        PreparedStatement st = null;
        Scanner miScan = new Scanner(System.in);

        System.out.println("Seleccione el color: 1 para Blanco, 2 para Negro");
        int color = miScan.nextInt();
        int idColor = (color == 1) ? 1 : 2;
        pieza.setIdColor(idColor);

        System.out.println("Seleccione el tipo de pieza para cargar:");
        System.out.println("1. Reina | 2. Rey | 3. Torre | 4. Alfil | 5. Caballo | 6. Peon");
        int op = miScan.nextInt();

        switch (op) {
            case 1:
                pieza.setDescripcion("Reina");
                pieza.setIdTipoPieza(1);
                break;
            case 2:
                pieza.setDescripcion("Rey");
                pieza.setIdTipoPieza(2);
                break;
            case 3:
                pieza.setDescripcion("Torre");
                pieza.setIdTipoPieza(3);
                break;
            case 4:
                pieza.setDescripcion("Alfil");
                pieza.setIdTipoPieza(4);
                break;
            case 5:
                pieza.setDescripcion("Caballo");
                pieza.setIdTipoPieza(5);
                break;
            case 6:
                pieza.setDescripcion("Peon");
                pieza.setIdTipoPieza(6);
                break;
            default:
                System.out.println("Opción incorrecta.");
                miScan.close();
                return;
        }

        System.out.println("Seleccione el tamaño de la pieza: 1 para Pequeño, 2 para Grande");
        int tamanio = miScan.nextInt();
        pieza.setIdTamanio(tamanio);

        System.out.println("Seleccione el material de la pieza: 1 para Plástico, 2 para Madera");
        int material = miScan.nextInt();
        pieza.setIdMaterial(material);

        try {
            con = accesoBD.getConexion();
            String query = "INSERT INTO pieza (Descripcion, idColor, IdTipoPieza, idTamanio, idMaterial, Posicion, Caracter, Movimiento, Fecha_Creacion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            st = con.prepareStatement(query);

            st.setString(1, pieza.getDescripcion());
            st.setInt(2, pieza.getIdColor());
            st.setInt(3, pieza.getIdTipoPieza());
            st.setInt(4, pieza.getIdTamanio());
            st.setInt(5, pieza.getIdMaterial());
            st.setString(6, pieza.getPosicion());
            st.setString(7, pieza.getCaracter());
            st.setString(8, pieza.getMovimiento());
            st.setDate(9, pieza.getFecha_creacion());

            st.executeUpdate();
            System.out.println("Datos insertados correctamente en la base de datos.");
        } catch (SQLException e) {
            System.err.println("Error al insertar los datos en la base de datos.");
            e.printStackTrace();
        } finally {
            try {
                if (st != null) st.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión.");
            }
            miScan.close();
        }
    }
}
