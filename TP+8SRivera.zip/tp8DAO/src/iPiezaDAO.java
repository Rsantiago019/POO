
public interface iPiezaDAO {
    public abstract void MostrarDatosDeLaBaseDeDato();
    public abstract void InsertarAlaBaseDeDatos(Pieza pieza);
}
