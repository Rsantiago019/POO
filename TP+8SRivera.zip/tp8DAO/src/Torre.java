import java.sql.Date;

public class Torre extends Pieza {
    public Torre( String Descripcion, int idColor , int idTipoPieza, int  idTamanio,int idMaterial, String Posicion, String Movimiento, Date Fecha_Creacion) 
   {
   super(  Descripcion, idColor ,  idTipoPieza,   idTamanio, idMaterial,  Posicion,  Movimiento,  Fecha_Creacion);
    }
    }
    

    
