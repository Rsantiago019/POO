import java.util.ArrayList;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        iPiezaDAO consulta = new PiezaDAO();
        ArrayList<Pieza> piezas = new ArrayList<>(); 

        Pieza pieza = new Pieza(null, 0, 0, 0, 0,
         null, null, null);
        
         Scanner miScan = new Scanner(System.in);    
        
         System.out.println("Bienvenido al puente de 2 mundos DB - POO");
        
         System.out.println("Elija una opcion : ");
        
         System.out.println("1 - listar piezas desde la base de datos");
        
         System.out.println("2 - Cargar piezas a la base de datos");
    
        boolean flag = true;
        while (flag) {
            int op = miScan.nextInt();
            switch (op) {
                case 1:
                    consulta.MostrarDatosDeLaBaseDeDato();
                    break;  
    
                case 2:
                    InstanciarPieza(pieza, piezas); 
                    consulta.InsertarAlaBaseDeDatos(pieza);
                    break;
    
                default:
                    System.out.println("Opción incorrecta");
                    break;
            }
        }
        miScan.close(); 
    }
    
    public static void InstanciarPieza(Pieza pieza, ArrayList<Pieza> piezas) {
        
        String[] posicionesPeonesBlancos = {"A2", "B2", "C2", "D2", "E2", "F2", "G2", "H2"};
        String[] posicionesPeonesNegros = {"A7", "B7", "C7", "D7", "E7", "F7", "G7", "H7"};
        String[] posicionesAlfilesBlancos = {"C1","F1"};
        String[] posicionesAlfilesNegros = {"C8","F8"};
        String[] posicionesTorresBlancas = {"A1","H1"};
        String[] posicionesTorresNegros = {"A8","H8"};
        String[] posicionesCaballosBlancos = {"B1","G1"};
        String[] posicionesCaballosNegros = {"B8","G8"};
        String[] posicionReina = {"D1", "D8"};
        String[] posicionRey = {"E1", "E8"};

        for (int i = 0; i < 8; i++) {
            Peon miPeonBlanco = new Peon(null, 0, 1, 2,
            1, posicionesPeonesBlancos[i], "1", null);
            
            Peon miPeonNegro = new Peon(null, 0, 6, 2,
             1, posicionesPeonesNegros[i], "1", null);
            
             piezas.add(miPeonBlanco); 
            
             piezas.add(miPeonNegro); 
        }

        for (int i = 0; i < 2; i++) {
            Alfil miAlfilBlanco = new Alfil(null, 0, 4,
             
            1, 1, posicionesAlfilesBlancos[i], "1", null);
           
            Alfil miAlfilNegro = new Alfil(null, 0, 4,
            
            1, 1, posicionesAlfilesNegros[i], "1", null);
            
            Torre miTorreBlanca = new Torre(null, 0, 3,
            
            1, 1, posicionesTorresBlancas[i], "1", null);
            
            Torre miTorreNegra = new Torre(null, 0, 3,
            
            1, 1, posicionesTorresNegros[i], "1", null);
            
            Caballo miCaballoBlanco = new Caballo(null, 0, 5, 
           
            1, 1, posicionesCaballosBlancos[i], "3", null);
            
            Caballo miCaballoNegro = new Caballo(null, 0, 5, 
           
            1, 1, posicionesCaballosNegros[i], "4", null);

            piezas.add(miAlfilBlanco);
            
            piezas.add(miAlfilNegro);
            
            piezas.add(miTorreBlanca);
            
            piezas.add(miTorreNegra);
            
            piezas.add(miCaballoBlanco);
            
            piezas.add(miCaballoNegro);
        }

        for (int i = 0; i < 1; i++) {
            Reina miReinaBlanca = new Reina(null, 0, 1,
             1, 1, posicionReina[0], "1", null);
            
             Reina miReinaNegra = new Reina(null, 0, 1,
              1, 1, posicionReina[1], "1", null);
            
              Rey miReyBlanco = new Rey(null, 1, 2, 
              1, 1, posicionRey[0], "1", null);
            
              Rey miReyNegro = new Rey(null, 0, 2,
               1, 1, posicionRey[1], "1", null);

            piezas.add(miReinaBlanca);
            
            piezas.add(miReinaNegra);

            piezas.add(miReyBlanco);
            
            piezas.add(miReyNegro);
        }
    }
}
