public class Casillero {
    
    private String Color;

    public String getColor() {
        return Color;
    }

    public void setColor(String color) {
        Color = color;
    }

    // Constructor Vacio
    public Casillero() {
    }
    //Constructor

    public Casillero(String color) {
        Color = color;
    }

   

}
